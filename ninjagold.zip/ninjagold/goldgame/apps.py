from django.apps import AppConfig


class GoldgameConfig(AppConfig):
    name = 'goldgame'
